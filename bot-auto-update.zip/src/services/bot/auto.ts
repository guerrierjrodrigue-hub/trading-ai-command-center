import { round } from "@/lib/utils";
import { atr, lastValid } from "@/services/market/indicators";
import { scanMarket, scoreOpportunity } from "@/services/scanner/scanner";
import type { MarketDataProvider } from "@/services/market/types";
import type { Timeframe } from "@/lib/validation";

export type RiskProfileName = "CONSERVATIVE" | "BALANCED" | "AGGRESSIVE";

export interface RiskProfile {
  label: string;
  riskPerTradePct: number;
  maxOpenPositions: number;
  maxExposurePct: number;
  entryScore: number; // min AI Opportunity Score to enter
  exitScore: number; // close if score falls below this
  atrMult: number; // stop distance = atrMult × ATR
  rr: number; // reward:risk for take-profit
  timeframe: Timeframe;
  avoidHighRisk: boolean; // skip HIGH-volatility assets
  fallbackStopPct: number; // if ATR unavailable
}

/**
 * Presets. The bot derives EVERYTHING from the chosen profile in AUTO mode:
 * which assets (scanner), when to enter/exit (score + trend), stop distance
 * (ATR-based), sizing, position count and exposure.
 */
export const RISK_PROFILES: Record<RiskProfileName, RiskProfile> = {
  CONSERVATIVE: {
    label: "Prudent",
    riskPerTradePct: 0.5,
    maxOpenPositions: 2,
    maxExposurePct: 25,
    entryScore: 68,
    exitScore: 48,
    atrMult: 2.5,
    rr: 2.5,
    timeframe: "1D",
    avoidHighRisk: true,
    fallbackStopPct: 4,
  },
  BALANCED: {
    label: "Équilibré",
    riskPerTradePct: 1,
    maxOpenPositions: 4,
    maxExposurePct: 50,
    entryScore: 60,
    exitScore: 45,
    atrMult: 2,
    rr: 2,
    timeframe: "1D",
    avoidHighRisk: false,
    fallbackStopPct: 5,
  },
  AGGRESSIVE: {
    label: "Agressif",
    riskPerTradePct: 2,
    maxOpenPositions: 6,
    maxExposurePct: 80,
    entryScore: 55,
    exitScore: 42,
    atrMult: 1.5,
    rr: 1.8,
    timeframe: "4h",
    avoidHighRisk: false,
    fallbackStopPct: 7,
  },
};

export interface AutoCloseDecision {
  id: string;
  reason: string;
}
export interface AutoOpenCandidate {
  symbol: string;
  entry: number;
  stop: number;
  tp: number;
  reason: string;
}

interface HeldPosition {
  id: string;
  asset: { symbol: string };
}

/**
 * Decides, from the scanner + volatility, which held positions to exit on
 * signal and which new assets to enter — all shaped by the risk profile.
 */
export async function autoPlan(
  provider: MarketDataProvider,
  profile: RiskProfile,
  held: HeldPosition[],
): Promise<{ closes: AutoCloseDecision[]; candidates: AutoOpenCandidate[] }> {
  const closes: AutoCloseDecision[] = [];
  const heldSymbols = new Set(held.map((p) => p.asset.symbol));

  // Signal-based exits for held positions.
  for (const pos of held) {
    const [candles, quote] = await Promise.all([
      provider.getCandles(pos.asset.symbol, profile.timeframe, 200).catch(() => []),
      provider.getQuote(pos.asset.symbol).catch(() => null),
    ]);
    if (!candles.length || !quote) continue;
    const scan = scoreOpportunity(candles, quote);
    if (scan.score < profile.exitScore || scan.trend === "DOWN") {
      closes.push({ id: pos.id, reason: `score IA ${scan.score} < ${profile.exitScore} ou tendance baissière` });
    }
  }

  // Entry candidates: scan everything, keep strong LONG setups within the profile.
  const results = await scanMarket(provider, {}); // sorted by score desc
  const candidates: AutoOpenCandidate[] = [];
  for (const r of results) {
    if (r.direction !== "LONG" || r.score < profile.entryScore) continue;
    if (profile.avoidHighRisk && r.risk === "HIGH") continue;
    if (heldSymbols.has(r.symbol)) continue;

    const candles = await provider.getCandles(r.symbol, profile.timeframe, 200).catch(() => []);
    const a = lastValid(atr(candles, 14)) ?? (r.price * profile.fallbackStopPct) / 100;
    const entry = r.price;
    const stop = round(entry - profile.atrMult * a, 6);
    if (stop <= 0 || stop >= entry) continue;
    const tp = round(entry + profile.rr * (entry - stop), 6);
    candidates.push({
      symbol: r.symbol,
      entry,
      stop,
      tp,
      reason: `score IA ${r.score} · ${r.setup} · stop ATR×${profile.atrMult}`,
    });
  }

  return { closes, candidates };
}
