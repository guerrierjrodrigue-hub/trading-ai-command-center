import { prisma } from "@/lib/prisma";
import { env } from "@/lib/env";
import { round } from "@/lib/utils";
import type { Timeframe } from "@/lib/validation";
import { getMarketDataProvider } from "@/services/market";
import { getCatalogAsset } from "@/services/market/catalog";
import { loadPortfolioState } from "@/services/trading/state";
import { planClose, planOpen } from "@/services/trading/paper-engine";
import { checkRiskLimits, computePositionSize } from "@/services/risk/position-sizing";
import { longSignal, type BotStrategy } from "./strategy";
import { RISK_PROFILES, autoPlan, type RiskProfileName } from "./auto";

async function log(userId: string, action: string, message: string, symbol?: string) {
  await prisma.botLog.create({ data: { userId, action, message, symbol: symbol ?? null } });
}

export interface BotCycleResult {
  ran: boolean;
  opened: number;
  closed: number;
  message: string;
}

type HeldPosition = Awaited<ReturnType<typeof loadHeld>>[number];
async function loadHeld(portfolioId: string) {
  return prisma.position.findMany({
    where: { portfolioId, status: "OPEN", openedBy: "BOT" },
    include: { asset: true },
  });
}

interface Candidate {
  symbol: string;
  entry: number;
  stop: number;
  tp: number;
  reason: string;
}

/**
 * Runs ONE decision cycle. PAPER only. Supports two modes:
 *  - MANUAL: user-chosen strategy + symbols + fixed % stop.
 *  - AUTO:   the bot picks assets/entries/exits/stops/sizing from the risk
 *            profile (scanner + ATR). The user only sets a risk level.
 * Stop-loss / take-profit are enforced generically for every bot position.
 */
export async function runBotCycle(userId: string): Promise<BotCycleResult> {
  const cfg = await prisma.botConfig.findUnique({ where: { userId } });
  if (!cfg || !cfg.enabled) return { ran: false, opened: 0, closed: 0, message: "bot désactivé" };

  const setting = await prisma.setting.findUnique({ where: { userId } });
  const feeBps = setting?.feeBps ?? env.paper.feeBps;
  const maxDailyLoss = setting?.maxDailyLossPct ?? 3;
  const provider = getMarketDataProvider();

  const state = await loadPortfolioState(userId);
  let cash = state.metrics.cash;
  const equity = state.metrics.equity;
  let opened = 0;
  let closed = 0;

  // Effective parameters (from the profile in AUTO, from the config in MANUAL).
  const isAuto = cfg.mode === "AUTO";
  const profile = RISK_PROFILES[cfg.riskProfile as RiskProfileName] ?? RISK_PROFILES.BALANCED;
  const eff = isAuto
    ? {
        riskPerTradePct: profile.riskPerTradePct,
        maxOpenPositions: profile.maxOpenPositions,
        maxExposurePct: profile.maxExposurePct,
        timeframe: profile.timeframe as Timeframe,
      }
    : {
        riskPerTradePct: cfg.riskPerTradePct,
        maxOpenPositions: cfg.maxOpenPositions,
        maxExposurePct: setting?.maxPortfolioExposurePct ?? 60,
        timeframe: cfg.timeframe as Timeframe,
      };

  // Shared close executor.
  async function execClose(pos: HeldPosition, price: number, reason: string) {
    const plan = planClose({ cash, side: "LONG", quantity: pos.quantity, entryPrice: pos.entryPrice, exitPrice: price, feeBps });
    cash = plan.cashAfter;
    await prisma.$transaction([
      prisma.position.update({ where: { id: pos.id }, data: { status: "CLOSED", exitPrice: price, realizedPnl: plan.pnl, feesPaid: pos.feesPaid + plan.fee, closedAt: new Date() } }),
      prisma.order.create({ data: { portfolioId: pos.portfolioId, assetId: pos.assetId, positionId: pos.id, side: "SELL", type: "MARKET", status: "FILLED", quantity: pos.quantity, price, fee: plan.fee, reason: "BOT close" } }),
      prisma.trade.create({ data: { portfolioId: pos.portfolioId, assetId: pos.assetId, positionId: pos.id, side: "LONG", quantity: pos.quantity, entryPrice: pos.entryPrice, exitPrice: price, fees: pos.feesPaid + plan.fee, pnl: plan.pnl, pnlPct: plan.pnlPct, openedAt: pos.openedAt } }),
      prisma.portfolio.update({ where: { id: pos.portfolioId }, data: { cash: plan.cashAfter } }),
    ]);
    await log(userId, "CLOSE", `${pos.asset.symbol} : ${reason} → P&L ${plan.pnl} (${plan.pnlPct}%)`, pos.asset.symbol);
    closed++;
  }

  const held = await loadHeld(state.portfolioId);

  // 1) Generic stop-loss / take-profit for every bot position.
  const survivors: HeldPosition[] = [];
  const priceCache = new Map<string, number>();
  for (const pos of held) {
    const quote = await provider.getQuote(pos.asset.symbol).catch(() => null);
    if (!quote) { survivors.push(pos); continue; }
    priceCache.set(pos.asset.symbol, quote.price);
    if (pos.stopLoss && quote.price <= pos.stopLoss) { await execClose(pos, quote.price, `stop-loss touché (${quote.price} ≤ ${pos.stopLoss})`); continue; }
    if (pos.takeProfit && quote.price >= pos.takeProfit) { await execClose(pos, quote.price, `take-profit atteint (${quote.price} ≥ ${pos.takeProfit})`); continue; }
    survivors.push(pos);
  }

  // 2) Mode-specific plan: which survivors to close on signal + entry candidates.
  const signalCloses: { id: string; reason: string }[] = [];
  let candidates: Candidate[] = [];

  if (isAuto) {
    const plan = await autoPlan(provider, profile, survivors.map((p) => ({ id: p.id, asset: { symbol: p.asset.symbol } })));
    signalCloses.push(...plan.closes);
    candidates = plan.candidates;
  } else {
    for (const pos of survivors) {
      const candles = await provider.getCandles(pos.asset.symbol, eff.timeframe, 200).catch(() => []);
      const sig = candles.length ? longSignal(candles, cfg.strategy as BotStrategy) : { long: true, reason: "" };
      if (!sig.long) signalCloses.push({ id: pos.id, reason: `signal de sortie — ${sig.reason}` });
    }
    let symbols = cfg.symbols;
    if (!symbols.length) {
      const wl = await prisma.watchlist.findFirst({ where: { userId }, include: { items: { include: { asset: true } } } });
      symbols = wl?.items.map((i) => i.asset.symbol) ?? [];
    }
    if (!symbols.length) symbols = ["BTC", "ETH", "SOL"];
    const heldSymbols = new Set(survivors.map((p) => p.asset.symbol));
    for (const symbol of symbols) {
      if (heldSymbols.has(symbol)) continue;
      const candles = await provider.getCandles(symbol, eff.timeframe, 200).catch(() => []);
      if (candles.length < 30) continue;
      const sig = longSignal(candles, cfg.strategy as BotStrategy);
      if (!sig.long) continue;
      const quote = await provider.getQuote(symbol).catch(() => null);
      if (!quote) continue;
      const entry = quote.price;
      const stop = round(entry * (1 - cfg.stopPct / 100), 6);
      const tp = round(entry * (1 + (cfg.stopPct * cfg.takeProfitRR) / 100), 6);
      candidates.push({ symbol, entry, stop, tp, reason: sig.reason });
    }
  }

  // 3) Execute signal closes.
  const stillOpen = new Map(survivors.map((p) => [p.id, p]));
  for (const c of signalCloses) {
    const pos = stillOpen.get(c.id);
    if (!pos) continue;
    const price = priceCache.get(pos.asset.symbol) ?? (await provider.getQuote(pos.asset.symbol).catch(() => null))?.price;
    if (price == null) continue;
    await execClose(pos, price, c.reason);
    stillOpen.delete(c.id);
  }

  // 4) Execute entries within limits.
  let openCount = stillOpen.size;
  const dailyLossPct = equity > 0 ? (-state.metrics.pnlToday / equity) * 100 : 0;
  for (const cand of candidates) {
    if (openCount >= eff.maxOpenPositions) break;
    if (dailyLossPct >= maxDailyLoss) { await log(userId, "SKIP", `Limite de perte quotidienne atteinte (${dailyLossPct.toFixed(1)}%)`); break; }
    let sizing;
    try { sizing = computePositionSize({ capital: equity, riskPct: eff.riskPerTradePct, entry: cand.entry, stop: cand.stop }); } catch { continue; }
    if (sizing.quantity <= 0) continue;
    const notional = sizing.quantity * cand.entry;
    const risk = checkRiskLimits(
      notional,
      { cash, openPositions: openCount, currentExposure: state.metrics.marketValue, capital: equity, realizedPnlToday: state.metrics.pnlToday },
      { riskPerTradePct: eff.riskPerTradePct, maxDailyLossPct: maxDailyLoss, maxOpenPositions: eff.maxOpenPositions, maxPortfolioExposurePct: eff.maxExposurePct },
    );
    if (!risk.allowed) { await log(userId, "SKIP", `${cand.symbol} : ${risk.violations[0]}`, cand.symbol); continue; }

    const cat = getCatalogAsset(cand.symbol);
    const asset = await prisma.asset.upsert({
      where: { symbol: cat?.symbol ?? cand.symbol },
      update: {},
      create: { symbol: cat?.symbol ?? cand.symbol, name: cat?.name ?? cand.symbol, assetClass: cat?.assetClass ?? "CRYPTO", quoteCurrency: cat?.quoteCurrency ?? "USD", exchange: cat?.exchange },
    });
    const plan = planOpen({ cash, side: "BUY", quantity: sizing.quantity, price: cand.entry, feeBps });
    cash = plan.cashAfter;
    const position = await prisma.position.create({
      data: { portfolioId: state.portfolioId, assetId: asset.id, side: "LONG", status: "OPEN", quantity: plan.quantity, entryPrice: plan.entryPrice, stopLoss: cand.stop, takeProfit: cand.tp, feesPaid: plan.fee, openedBy: "BOT" },
    });
    await prisma.order.create({ data: { portfolioId: state.portfolioId, assetId: asset.id, positionId: position.id, side: "BUY", type: "MARKET", status: "FILLED", quantity: plan.quantity, price: plan.entryPrice, fee: plan.fee, reason: "BOT open" } });
    await prisma.portfolio.update({ where: { id: state.portfolioId }, data: { cash: plan.cashAfter } });
    await log(userId, "OPEN", `${cand.symbol} : achat ${plan.quantity} @ ${plan.entryPrice} — ${cand.reason} · stop ${cand.stop} · TP ${cand.tp}`, cand.symbol);
    opened++;
    openCount++;
  }

  await prisma.botConfig.update({ where: { userId }, data: { lastRunAt: new Date() } });
  if (opened === 0 && closed === 0) {
    await log(userId, "INFO", `Cycle ${isAuto ? "autonome" : "manuel"} terminé — aucune action.`);
  }
  return { ran: true, opened, closed, message: `Cycle terminé : ${opened} ouverture(s), ${closed} clôture(s).` };
}
