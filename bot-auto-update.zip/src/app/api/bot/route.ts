import { authUserId, ok, parseBody } from "@/lib/api";
import { prisma } from "@/lib/prisma";
import { botConfigSchema } from "@/lib/validation";
import { RISK_PROFILES } from "@/services/bot/auto";

async function ensureConfig(userId: string) {
  const existing = await prisma.botConfig.findUnique({ where: { userId } });
  if (existing) return existing;
  return prisma.botConfig.create({ data: { userId } });
}

export async function GET() {
  const auth = await authUserId();
  if ("response" in auth) return auth.response;

  const config = await ensureConfig(auth.userId);
  const [logs, portfolio] = await Promise.all([
    prisma.botLog.findMany({ where: { userId: auth.userId }, orderBy: { createdAt: "desc" }, take: 50 }),
    prisma.portfolio.findFirst({ where: { userId: auth.userId } }),
  ]);
  const positions = portfolio
    ? await prisma.position.findMany({
        where: { portfolioId: portfolio.id, status: "OPEN", openedBy: "BOT" },
        include: { asset: true },
        orderBy: { openedAt: "desc" },
      })
    : [];

  return ok({
    config,
    profiles: RISK_PROFILES,
    logs,
    positions: positions.map((p) => ({
      id: p.id,
      symbol: p.asset.symbol,
      quantity: p.quantity,
      entryPrice: p.entryPrice,
      stopLoss: p.stopLoss,
      takeProfit: p.takeProfit,
      openedAt: p.openedAt.toISOString(),
    })),
  });
}

export async function PATCH(req: Request) {
  const auth = await authUserId();
  if ("response" in auth) return auth.response;
  const parsed = await parseBody(req, botConfigSchema);
  if ("response" in parsed) return parsed.response;
  await ensureConfig(auth.userId);
  const config = await prisma.botConfig.update({
    where: { userId: auth.userId },
    data: {
      ...parsed.data,
      symbols: parsed.data.symbols
        ? parsed.data.symbols.map((s) => s.toUpperCase())
        : undefined,
    },
  });
  return ok({ config });
}
