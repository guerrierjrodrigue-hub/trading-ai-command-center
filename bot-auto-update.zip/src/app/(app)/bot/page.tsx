"use client";

import { useEffect, useState } from "react";
import { Bot, Play, Power } from "lucide-react";
import { Badge, Card, Empty, ErrorNote, PaperBadge, SectionTitle, Spinner } from "@/components/ui";
import { apiSend, useFetch } from "@/lib/client";
import { cn, formatCurrency } from "@/lib/utils";

interface BotConfig {
  enabled: boolean;
  mode: string;
  riskProfile: string;
  strategy: string;
  timeframe: string;
  symbols: string[];
  riskPerTradePct: number;
  stopPct: number;
  takeProfitRR: number;
  maxOpenPositions: number;
  intervalMinutes: number;
  lastRunAt: string | null;
}
interface Profile {
  label: string;
  riskPerTradePct: number;
  maxOpenPositions: number;
  maxExposurePct: number;
  entryScore: number;
  atrMult: number;
  rr: number;
  timeframe: string;
}
interface BotLog {
  id: string;
  action: string;
  symbol: string | null;
  message: string;
  createdAt: string;
}
interface BotPosition {
  id: string;
  symbol: string;
  quantity: number;
  entryPrice: number;
  stopLoss: number | null;
  takeProfit: number | null;
}

const STRATEGIES = ["EMA_CROSS", "MACD", "RSI", "BREAKOUT", "TREND_FOLLOWING"];
const TIMEFRAMES = ["1h", "4h", "1D", "1W"];

const actionTone: Record<string, "pos" | "neg" | "warn" | "cyan" | "neutral"> = {
  OPEN: "pos",
  CLOSE: "neg",
  HOLD: "neutral",
  SKIP: "warn",
  INFO: "cyan",
  ERROR: "neg",
};

export default function BotPage() {
  const data = useFetch<{ config: BotConfig; profiles: Record<string, Profile>; logs: BotLog[]; positions: BotPosition[] }>("/api/bot");
  const [form, setForm] = useState<BotConfig | null>(null);
  const [symbolsText, setSymbolsText] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (data.data?.config && !form) {
      setForm(data.data.config);
      setSymbolsText(data.data.config.symbols.join(", "));
    }
  }, [data.data, form]);

  async function patch(partial: Partial<BotConfig>) {
    setError(null);
    try {
      const res = await apiSend<{ config: BotConfig }>("/api/bot", "PATCH", partial);
      setForm(res.config);
      await data.refetch();
      return res.config;
    } catch (e) {
      setError((e as Error).message);
    }
  }

  async function toggle() {
    if (!form) return;
    setBusy(true);
    await patch({ enabled: !form.enabled });
    setBusy(false);
  }

  async function saveConfig(e: React.FormEvent) {
    e.preventDefault();
    if (!form) return;
    setBusy(true);
    setMsg(null);
    const symbols = symbolsText.split(/[,\s]+/).map((s) => s.trim().toUpperCase()).filter(Boolean);
    const res = await patch({
      mode: form.mode,
      riskProfile: form.riskProfile,
      strategy: form.strategy,
      timeframe: form.timeframe,
      symbols,
      riskPerTradePct: Number(form.riskPerTradePct),
      stopPct: Number(form.stopPct),
      takeProfitRR: Number(form.takeProfitRR),
      maxOpenPositions: Number(form.maxOpenPositions),
      intervalMinutes: Number(form.intervalMinutes),
    });
    if (res) setMsg("Configuration enregistrée.");
    setBusy(false);
  }

  async function runNow() {
    setBusy(true);
    setMsg(null);
    setError(null);
    try {
      const r = await apiSend<{ opened: number; closed: number; message: string }>("/api/bot/run", "POST");
      setMsg(r.message);
      await data.refetch();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  const set = <K extends keyof BotConfig>(k: K, v: BotConfig[K]) => setForm((f) => (f ? { ...f, [k]: v } : f));

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <h1 className="text-2xl font-semibold text-white">Auto-Pilot</h1>
        <Bot className="h-5 w-5 text-accent-soft" />
        <PaperBadge />
      </div>

      <div className="rounded-lg border border-warn/40 bg-warn/10 p-3 text-sm text-warn">
        Le robot applique des stratégies techniques avec gestion du risque, <b>en simulation
        uniquement</b>. Ce n&apos;est pas un conseil financier et il peut subir des pertes (fictives).
        Aucun ordre réel n&apos;est passé.
      </div>

      {data.error && <ErrorNote message={data.error} />}
      {data.loading && !form && <Spinner />}
      {error && <ErrorNote message={error} />}

      {form && (
        <>
          <Card>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <button onClick={toggle} disabled={busy} className={cn("flex items-center gap-2", form.enabled ? "btn-neg" : "btn-pos")}>
                  <Power className="h-4 w-4" />
                  {form.enabled ? "Arrêter le robot" : "Démarrer le robot"}
                </button>
                <Badge tone={form.enabled ? "pos" : "neutral"}>{form.enabled ? "EN MARCHE" : "ARRÊTÉ"}</Badge>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-xs text-faint">
                  {form.lastRunAt ? `Dernier cycle : ${new Date(form.lastRunAt).toLocaleString("fr-CA")}` : "Jamais exécuté"}
                  {" · "}toutes les {form.intervalMinutes} min
                </span>
                <button onClick={runNow} disabled={busy} className="btn-ghost text-xs">
                  <Play className="h-4 w-4" /> Lancer un cycle maintenant
                </button>
              </div>
            </div>
            {msg && <p className="mt-3 text-sm text-pos">{msg}</p>}
          </Card>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <SectionTitle title="Configuration" />
              <form onSubmit={saveConfig} className="space-y-3">
                <div>
                  <label className="label">Mode</label>
                  <div className="flex gap-2">
                    <button type="button" onClick={() => set("mode", "AUTO")} className={cn("flex-1 text-xs", form.mode === "AUTO" ? "btn-primary" : "btn-ghost")}>🤖 Autonome</button>
                    <button type="button" onClick={() => set("mode", "MANUAL")} className={cn("flex-1 text-xs", form.mode === "MANUAL" ? "btn-primary" : "btn-ghost")}>Manuel</button>
                  </div>
                </div>

                {form.mode === "AUTO" ? (
                  <>
                    <div>
                      <label className="label">Niveau de risque</label>
                      <select className="input" value={form.riskProfile} onChange={(e) => set("riskProfile", e.target.value)}>
                        <option value="CONSERVATIVE">Prudent</option>
                        <option value="BALANCED">Équilibré</option>
                        <option value="AGGRESSIVE">Agressif</option>
                      </select>
                    </div>
                    {(() => {
                      const prof = data.data?.profiles?.[form.riskProfile];
                      if (!prof) return null;
                      return (
                        <div className="space-y-1 rounded-lg border border-border bg-bg-soft p-3 text-xs text-muted">
                          <div className="uppercase tracking-wide text-faint">Le robot décide tout, calibré « {prof.label} » :</div>
                          <div className="grid grid-cols-2 gap-x-4 gap-y-1 tnum">
                            <span>Risque / trade</span><span className="text-right text-white">{prof.riskPerTradePct}%</span>
                            <span>Positions max</span><span className="text-right text-white">{prof.maxOpenPositions}</span>
                            <span>Exposition max</span><span className="text-right text-white">{prof.maxExposurePct}%</span>
                            <span>Seuil d&apos;entrée (score IA)</span><span className="text-right text-white">≥ {prof.entryScore}</span>
                            <span>Stop-loss</span><span className="text-right text-white">ATR × {prof.atrMult}</span>
                            <span>Objectif R/R</span><span className="text-right text-white">{prof.rr}</span>
                            <span>Timeframe</span><span className="text-right text-white">{prof.timeframe}</span>
                          </div>
                          <div className="text-faint">Actifs choisis automatiquement par le scanner.</div>
                        </div>
                      );
                    })()}
                  </>
                ) : (
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="label">Stratégie</label>
                      <select className="input" value={form.strategy} onChange={(e) => set("strategy", e.target.value)}>
                        {STRATEGIES.map((s) => <option key={s}>{s}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="label">Timeframe</label>
                      <select className="input" value={form.timeframe} onChange={(e) => set("timeframe", e.target.value)}>
                        {TIMEFRAMES.map((t) => <option key={t}>{t}</option>)}
                      </select>
                    </div>
                    <div><label className="label">Risque / trade (%)</label><input className="input" value={form.riskPerTradePct} onChange={(e) => set("riskPerTradePct", e.target.value as unknown as number)} /></div>
                    <div><label className="label">Stop (%)</label><input className="input" value={form.stopPct} onChange={(e) => set("stopPct", e.target.value as unknown as number)} /></div>
                    <div><label className="label">Ratio R/R (take-profit)</label><input className="input" value={form.takeProfitRR} onChange={(e) => set("takeProfitRR", e.target.value as unknown as number)} /></div>
                    <div><label className="label">Positions max</label><input className="input" value={form.maxOpenPositions} onChange={(e) => set("maxOpenPositions", e.target.value as unknown as number)} /></div>
                    <div className="col-span-2">
                      <label className="label">Actifs (vide = ta watchlist)</label>
                      <input className="input" value={symbolsText} onChange={(e) => setSymbolsText(e.target.value)} placeholder="ex. BTC, ETH, SOL" />
                    </div>
                  </div>
                )}

                <div>
                  <label className="label">Intervalle (min)</label>
                  <input className="input" value={form.intervalMinutes} onChange={(e) => set("intervalMinutes", e.target.value as unknown as number)} />
                </div>
                <button type="submit" className="btn-primary" disabled={busy}>Enregistrer</button>
              </form>
            </Card>

            <Card>
              <SectionTitle title="Positions gérées par le robot" />
              {!data.data?.positions.length ? (
                <Empty message="Aucune position ouverte par le robot." />
              ) : (
                <div className="space-y-2">
                  {data.data.positions.map((p) => (
                    <div key={p.id} className="rounded-lg border border-border bg-bg-soft p-3 text-sm">
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-white">{p.symbol}</span>
                        <span className="tnum text-faint">{p.quantity} @ {formatCurrency(p.entryPrice)}</span>
                      </div>
                      <div className="tnum text-xs text-faint">
                        stop {p.stopLoss ? formatCurrency(p.stopLoss) : "—"} · TP {p.takeProfit ? formatCurrency(p.takeProfit) : "—"}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </Card>
          </div>

          <Card>
            <SectionTitle title="Journal du robot" subtitle="Chaque décision est expliquée" />
            {!data.data?.logs.length ? (
              <Empty message="Aucune activité pour l'instant. Démarre le robot ou lance un cycle." />
            ) : (
              <div className="max-h-96 space-y-1 overflow-y-auto">
                {data.data.logs.map((l) => (
                  <div key={l.id} className="flex items-start gap-2 border-b border-border/60 py-1.5 text-sm">
                    <span className="w-32 shrink-0 text-xs text-faint">{new Date(l.createdAt).toLocaleString("fr-CA")}</span>
                    <Badge tone={actionTone[l.action] ?? "neutral"}>{l.action}</Badge>
                    <span className="text-muted">{l.message}</span>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </>
      )}
    </div>
  );
}
